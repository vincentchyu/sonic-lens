import json
import os
import re

# 1. 扫描 binlogs 中的全量流派字符串
binlog_dir = "./scratch/binlogs"
binlog_genres = set()

if os.path.exists(binlog_dir):
    for file in os.listdir(binlog_dir):
        if not file.startswith("binlog."):
            continue
        path = os.path.join(binlog_dir, file)
        with open(path, "rb") as f:
            content = f.read()
            # 匹配典型的流派英文词汇模式（字母、空格、连字符）
            matches = re.findall(rb"[\x20-\x7e\xe4-\xe9][\x20-\x7e\x80-\xbf]{2,40}", content)
            for m in matches:
                try:
                    s = m.decode("utf-8").strip()
                    if (
                        len(s) >= 3
                        and len(s) <= 40
                        and not s.startswith("http")
                        and not s.startswith("select")
                        and not s.startswith("insert")
                        and not s.startswith("delete")
                        and not s.startswith("update")
                        and not s.startswith("multimedia")
                        and not s.startswith("binlog")
                        and not re.search(r"[0-9{}\[\]:;,]", s)
                    ):
                        binlog_genres.add(s)
                except Exception:
                    pass

print(f"Extracted {len(binlog_genres)} candidate genres from binlogs.")
