import os
import struct

binlog_dir = "./scratch/binlogs"

# 收集所有从 binlog 还原出的 (name, name_zh, play_count)
recovered_genres = {}

# 辅助正则表达式寻找字符串
import re

for file in sorted(os.listdir(binlog_dir)):
    if not file.startswith("binlog."):
        continue
    path = os.path.join(binlog_dir, file)
    with open(path, "rb") as f:
        data = f.read()

    # 寻找包含 "multimedia" "genre" 的 Table_map 区域或包含流派文本区域
    # 通过查找连续的可打印字符 / UTF-8 字符库
    # 在 binlog 的 byte 流里提取流派名称模式
    pos = 0
    while True:
        # 寻找与 "genre" 相关的 byte 序列
        idx = data.find(b"genre", pos)
        if idx == -1:
            break
        
        pos = idx + 5
        # 提取周围 500 字节中的 UTF-8 字段
        chunk = data[max(0, idx - 50):min(len(data), idx + 2000)]
        
        # 找匹配流派名的连续文本（英文字母、空格、斜杠、连字符、中文）
        matches = re.findall(rb"[\x20-\x7e\xe4-\xe9][\x20-\x7e\x80-\xbf]{2,80}", chunk)
        for m in matches:
            try:
                s = m.decode("utf-8").strip()
                # 过滤明显不是流派名的系统标记
                if (
                    len(s) >= 2
                    and not s.startswith("multimedia")
                    and not s.startswith("binlog")
                    and not s.startswith("SELECT")
                    and not s.startswith("INSERT")
                    and not s.startswith("UPDATE")
                    and not s.startswith("DELETE")
                    and not s.startswith("SET ")
                    and not s.startswith("WHERE ")
                    and not s.startswith("FROM ")
                    and "{" not in s
                    and "}" not in s
                    and "(" not in s
                    and ")" not in s
                    and "[" not in s
                    and "]" not in s
                ):
                    if s not in recovered_genres:
                        recovered_genres[s] = 0
            except Exception:
                pass

print(f"Total candidate genre strings extracted from binlogs: {len(recovered_genres)}")

# 输出前 50 个提取到的流派名
for s in sorted(list(recovered_genres.keys()))[:50]:
    print("Recovered Genre:", repr(s))
