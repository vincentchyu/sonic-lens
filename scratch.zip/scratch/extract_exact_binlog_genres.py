import json
import re

dump_file = "./scratch/real_binlog_dump.sql"

# 保存从 225M binlog dump 中提取出的真正原始 genre 记录 (按 id 去重保留最新值)
real_genre_map = {}  # id -> {id, name, name_zh, play_count}

print("🚀 开始全量扫描 225M 真实 binlog dump 文件...")

current_table = None

with open(dump_file, "r", encoding="utf-8", errors="ignore") as f:
    for line in f:
        # 跟踪 Table_map
        if "Table_map:" in line:
            if "`multimedia`.`genre`" in line or "`genre`" in line:
                current_table = "genre"
            else:
                current_table = None
            continue
        
        # 提取被 WRITE 或 DELETE 的行数据
        if current_table == "genre" and ("### INSERT INTO" in line or "### DELETE FROM" in line or "### UPDATE" in line):
            # 行开始
            pass
        
        if current_table == "genre" and line.startswith("###   @"):
            # 形如 ###   @1=2193
            # 形如 ###   @2='迷幻'
            # 形如 ###   @3=''
            # 形如 ###   @4=6
            parts = line.strip().split("=", 1)
            if len(parts) == 2:
                col_num = parts[0].replace("###   @", "").strip()
                val = parts[1].strip()
                # 剥离单引号
                if val.startswith("'") and val.endswith("'"):
                    val = val[1:-1]
                
                # 行边界记录
                if col_num == "1":
                    try:
                        cur_id = int(val)
                        if cur_id not in real_genre_map:
                            real_genre_map[cur_id] = {"id": cur_id, "name": "", "name_zh": "", "play_count": 0}
                        cur_record_id = cur_id
                    except Exception:
                        pass
                elif col_num == "2" and 'cur_record_id' in locals() and cur_record_id in real_genre_map:
                    real_genre_map[cur_record_id]["name"] = val
                elif col_num == "3" and 'cur_record_id' in locals() and cur_record_id in real_genre_map:
                    real_genre_map[cur_record_id]["name_zh"] = val
                elif col_num == "4" and 'cur_record_id' in locals() and cur_record_id in real_genre_map:
                    try:
                        real_genre_map[cur_record_id]["play_count"] = int(val)
                    except Exception:
                        pass

print(f"🎯 从 225M 真实 binlog dump 中精准提取到真正原始 `genre` 物理行记录: {len(real_genre_map)} 条！")

# 保存提取结果
with open("./scratch/exact_historical_genres.json", "w", encoding="utf-8") as out:
    json.dump(real_genre_map, out, ensure_ascii=False, indent=2)

# 打印抽样
print("\n抽样展现真正历史被删除的数据前 20 条:")
count = 0
for g_id, item in real_genre_map.items():
    if item["name"]:
        print(f"ID: {g_id:<5} | Name: {item['name']:<25} | NameZh: {item['name_zh']:<15} | PlayCount: {item['play_count']}")
        count += 1
        if count >= 20:
            break
