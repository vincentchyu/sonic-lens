import json
import pymysql

# 1. 读取从 binlog 中提取出的 2222 条真实历史记录
with open("./scratch/exact_historical_genres.json", "r", encoding="utf-8") as f:
    records = json.load(f)

print(f"🚀 准备将 binlog 中还原出的 2222 条真正原始历史记录恢复导回 MySQL...")

conn = pymysql.connect(
    host="127.0.0.1",
    port=3306,
    user="root",
    password="66243766",
    database="multimedia",
    charset="utf8mb4",
    autocommit=False
)

cursor = conn.cursor()

try:
    # A. 彻底清空刚才人工生成的虚构合成数据
    cursor.execute("TRUNCATE TABLE genre;")
    print("🧹 已清空虚构合成数据")

    # B. 按照原始 ID、原始 Name、原始 NameZh 导出真正的历史行
    sql = "INSERT INTO genre (id, name, name_zh, extra, play_count, created_at, updated_at) VALUES (%s, %s, %s, '', 0, NOW(), NOW()) ON DUPLICATE KEY UPDATE name_zh = VALUES(name_zh);"
    
    insert_data = []
    for g_id_str, item in records.items():
        g_id = int(g_id_str)
        name = item.get("name") or ""
        name_zh = item.get("name_zh") or ""
        if name:
            insert_data.append((g_id, name, name_zh))

    cursor.executemany(sql, insert_data)
    conn.commit()
    print(f"✅ 已成功将真正的 {len(insert_data)} 条原始历史流派物理行按原 ID 精确还原入库！")

except Exception as e:
    conn.rollback()
    print(f"❌ 恢复过程出错: {e}")
finally:
    cursor.close()
    conn.close()
