import os
import re

binlog_dir = "./scratch/binlogs"
extracted_strings = set()

# 正则匹配 UTF-8 英文/中文词汇序列
for file in sorted(os.listdir(binlog_dir)):
    if not file.startswith("binlog."):
        continue
    path = os.path.join(binlog_dir, file)
    with open(path, "rb") as f:
        content = f.read()
        
        # 寻找与 "genre" 相关的文本汇聚块
        for match in re.finditer(rb"genre", content, re.IGNORECASE):
            start = max(0, match.start() - 100)
            end = min(len(content), match.end() + 300)
            snippet = content[start:end]
            
            # 提取其中可打印的 utf-8 字符串
            sub_strs = re.findall(rb"[\x20-\x7e\xe4-\xe9][\x20-\x7e\x80-\xbf]{2,50}", snippet)
            for s in sub_strs:
                try:
                    text = s.decode("utf-8").strip()
                    if len(text) > 1 and not text.startswith("binlog") and not text.startswith("multimedia"):
                        extracted_strings.add(text)
                except Exception:
                    pass

print(f"Extracted string candidates count: {len(extracted_strings)}")
for s in list(extracted_strings)[:30]:
    print("Candidate:", s)
