import json
from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.row_event import DeleteRowsEvent, UpdateRowsEvent, WriteRowsEvent

MYSQL_SETTINGS = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "root",
    "passwd": "66243766",
}

# 遍历所有可用 binlog 日志
binlogs = [
    "binlog.000010", "binlog.000011", "binlog.000012", "binlog.000013",
    "binlog.000014", "binlog.000015", "binlog.000016", "binlog.000017",
    "binlog.000018", "binlog.000019", "binlog.000020"
]

all_original_genre_rows = {}

for log_file in binlogs:
    print(f"🔍 Reading binlog stream from {log_file}...")
    try:
        stream = BinLogStreamReader(
            connection_settings=MYSQL_SETTINGS,
            server_id=999999,
            log_file=log_file,
            log_pos=4,
            only_tables=["genre"],
            only_schemas=["multimedia"],
            blocking=False,
            ignored_events=[]
        )

        count = 0
        for event in stream:
            if isinstance(event, (DeleteRowsEvent, WriteRowsEvent, UpdateRowsEvent)):
                for row in event.rows:
                    # 针对 DeleteRowsEvent, row 是 {"values": {...}}
                    # 针对 UpdateRowsEvent, row 是 {"before_values": {...}, "after_values": {...}}
                    row_data = row.get("values") or row.get("before_values") or row.get("after_values")
                    if row_data:
                        g_id = row_data.get("id")
                        name = row_data.get("name")
                        name_zh = row_data.get("name_zh")
                        play_count = row_data.get("play_count", 0)
                        if name:
                            all_original_genre_rows[name] = {
                                "id": g_id,
                                "name": name,
                                "name_zh": name_zh,
                                "play_count": play_count
                            }
                            count += 1
        stream.close()
        print(f"  -> Extracted {count} rows from {log_file}")
    except Exception as e:
        print(f"  -> Skipping {log_file}: {e}")

print(f"\n🎉 完美通过 binlog 抓取到真正原始的 genre 行记录数: {len(all_original_genre_rows)} 条")

with open("./scratch/original_genres.json", "w", encoding="utf-8") as f:
    json.dump(all_original_genre_rows, f, ensure_ascii=False, indent=2)

for k, v in list(all_original_genre_rows.items())[:20]:
    print("Exact Real Record:", v)
